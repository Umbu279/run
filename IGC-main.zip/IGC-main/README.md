#### Link download termux : https://f-droid.org/repo/com.termux_117.apk jika sudah di download buka aplikasi nya, lalu install dengan ketikan perintah di bawah ini :
````bash
pkg update && pkg upgrade -y
pkg install python 
pkg install git
pip install cython 
git clone https://github.com/ncek-xd/IGC
````
Jika semua sudah terinstall kalian tinggal jalankan script dengan ketikan perintah di bawah ini :
````bash
cd $HOME/IGC
python run.py
````
Untuk update script / mendapatkan update terbaru. Ketikan perintah di bawah ini :
````
cd $HOME/IGC
git pull
````
Jika script masih belum update / tidak bisa update. Ketikan perintah di bawah ini :
````
cd $HOME
rm -rf IGC
git clone https://github.com/Ncek-XD/IGC 
````

# Hasil
<img src="https://github.com/ncek-XD/IGC/blob/main/Screenshot_2022-07-03-12-21-36-343_com.termux.jpg" width="640" title="Menu" alt="Menu">
